# AI Key Autofill

An Android `AutofillService` that recognizes API-key fields in any BYOK
(bring-your-own-key) app — OpenAI, Gemini, Anthropic, Mistral, Groq,
OpenRouter — and offers to fill them, the same way Google/1Password
autofill passwords. Zero-cost stack: Jetpack libraries only, no backend,
no paid SDKs.

## What this does NOT do, on purpose

It does not create accounts or generate keys on any provider automatically.
Every provider's Terms of Service prohibits scripted account creation, and
all of them gate key issuance behind email/phone verification and CAPTCHA
that's specifically designed to resist automation. Building that would get
this app delisted and would burn users' provider accounts. Instead:

- **"Add a key"** opens the provider's real console page in a Custom Tab,
  using the user's own logged-in browser session. The user creates the key
  themselves, in the provider's own UI, same as always.
- The app then **captures the key on paste** — either back in this app, or
  directly in whatever BYOK app the user pastes it into (via
  `onSaveRequest`) — validates its shape, and encrypts it into the vault.

That's the entire "automation": removing the copy-paste-search-for-the-
field friction, not the account/key-issuance step itself.

## Architecture

```
app/
  service/AiKeyAutofillService.kt   -- onFillRequest / onSaveRequest
  detect/FieldDetector.kt           -- heuristics: which field wants which key
  crypto/KeyVault.kt                -- EncryptedSharedPreferences (Keystore-backed AES-256-GCM)
  model/Provider.kt                 -- per-provider regex, field hints, console URL
  ui/MainActivity.kt                -- enable service, list/remove saved keys
  ui/AddKeyActivity.kt              -- deep link to console + paste-to-save
  ui/UnlockActivity.kt              -- BiometricPrompt gate before any fill value is revealed
```

**Fill flow:** `onFillRequest` walks the `AssistStructure`, scores candidate
`EditText` nodes against field hints + key-prefix patterns
(`FieldDetector`), and for each match builds a `Dataset` whose value is
`null` and whose `setAuthentication()` points at `UnlockActivity`. Nothing
decrypts until the user taps the dataset AND passes biometrics —
`UnlockActivity` only then reads `KeyVault`, wraps the real key in an
`AutofillValue`, and returns it via
`AutofillManager.EXTRA_AUTHENTICATION_RESULT`.

**Save flow:** `onSaveRequest` re-scans the structure for the typed value,
matches it against every provider's key regex (`sk-ant-...`, `AIza...`,
`sk-...`, etc.), and stores it under that provider's slot with a label
noting which app it came from.

**Storage:** `androidx.security.crypto.EncryptedSharedPreferences`, backed
by a hardware `MasterKey` (AES-256-GCM) in the Android Keystore. The vault
file is explicitly excluded from cloud backup and device-transfer in
`data_extraction_rules.xml`, on top of `allowBackup=false`.

## Setup

1. Open in Android Studio (Koala+ recommended), let Gradle sync.
2. Run on a device/emulator running API 26+ with a screen lock configured
   (biometrics require it).
3. Launch the app, tap **Enable**, select "AI Key Autofill" as the system
   autofill service.
4. Tap **Add a key**, pick a provider, tap **Open provider console**,
   create/copy a key on the provider's site, come back and paste it.
5. Open any BYOK app with an API-key field and tap into it — the fill
   suggestion should appear above the keyboard.

## Honest gaps to close before shipping

- **Field detection is heuristic, not guaranteed.** Apps that render key
  inputs inside a `WebView` or custom Compose text field without proper
  autofill semantics may not surface an `AssistStructure` node we can
  match at all. Worth testing against the top 10–15 BYOK apps by hand and
  tuning `FieldDetector`'s scoring/thresholds against real hint strings.
- **Multiple keys per provider** (e.g. personal vs. work OpenAI key) — the
  vault schema above stores one slot per provider id; extending to a list
  per provider is a small `KeyVault` change, deferred here to keep the
  first version simple.
- **RemoteViews preview theming** — the preview layout is intentionally
  plain; skinning it to match light/dark system autofill UI is a
  five-minute follow-up once you've got it running and can see it live.
- **No auto-validation of a pasted key against the provider's API** (e.g.
  a cheap "list models" call to confirm it's live, not just shaped right).
  Straightforward to add per-provider, left out here since it needs a
  network call at save-time and each provider's validation endpoint
  differs.
