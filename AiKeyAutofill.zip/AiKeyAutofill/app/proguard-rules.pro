# Keep autofill service class names stable (referenced from manifest/system)
-keep class com.aikeyautofill.app.service.** { *; }
-keep class com.aikeyautofill.app.model.** { *; }
