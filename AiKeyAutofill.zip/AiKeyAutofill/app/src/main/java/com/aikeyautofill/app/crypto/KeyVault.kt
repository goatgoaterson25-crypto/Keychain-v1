package com.aikeyautofill.app.crypto

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.aikeyautofill.app.model.Provider
import org.json.JSONObject

/**
 * Single source of truth for stored keys. Backed by Jetpack Security's
 * EncryptedSharedPreferences, which wraps a hardware-backed AES-256-GCM
 * MasterKey in the Android Keystore -- the key material itself never leaves
 * the secure element/TEE, and the file on disk is ciphertext only.
 *
 * Every value we store is itself a small JSON blob: { "key": ..., "label": ... }
 * keyed by provider id, plus an optional "custom:<uuid>" namespace for
 * multiple keys per provider (e.g. personal + work OpenAI keys).
 *
 * NOTE: EncryptedSharedPreferences on its own does not require biometric
 * auth to read -- that gate lives one layer up, in UnlockActivity, which the
 * AutofillService routes through via an IntentSender before a Dataset's
 * value is ever materialized. See AiKeyAutofillService.kt.
 */
class KeyVault private constructor(private val prefs: SharedPreferences) {

    data class StoredKey(val providerId: String, val label: String, val value: String)

    fun put(providerId: String, label: String, value: String) {
        val obj = JSONObject().put("label", label).put("value", value)
        prefs.edit().putString(entryKey(providerId), obj.toString()).apply()
    }

    fun get(providerId: String): StoredKey? {
        val raw = prefs.getString(entryKey(providerId), null) ?: return null
        val obj = JSONObject(raw)
        return StoredKey(providerId, obj.getString("label"), obj.getString("value"))
    }

    fun delete(providerId: String) {
        prefs.edit().remove(entryKey(providerId)).apply()
    }

    fun all(): List<StoredKey> =
        Provider.ALL.mapNotNull { get(it.id) }

    private fun entryKey(providerId: String) = "key_$providerId"

    companion object {
        @Volatile private var instance: KeyVault? = null

        fun get(context: Context): KeyVault =
            instance ?: synchronized(this) {
                instance ?: build(context.applicationContext).also { instance = it }
            }

        private fun build(context: Context): KeyVault {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            val prefs = EncryptedSharedPreferences.create(
                context,
                "ai_key_store_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            return KeyVault(prefs)
        }
    }
}
