package com.aikeyautofill.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.autofill.Dataset
import android.view.autofill.AutofillId
import android.view.autofill.AutofillValue
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.aikeyautofill.app.R
import com.aikeyautofill.app.crypto.KeyVault
import androidx.fragment.app.FragmentActivity

/**
 * Invisible/transparent activity launched via the Dataset's authentication
 * IntentSender (see AiKeyAutofillService.buildLockedDataset). Its entire job:
 * prompt for biometrics, and only on success, decrypt the requested key from
 * the vault and hand it back to the Autofill framework as the fill result.
 *
 * If the user cancels or auth fails, we finish with RESULT_CANCELED and no
 * value is ever produced -- the field simply doesn't get filled.
 */
class UnlockActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val providerId = intent.getStringExtra(EXTRA_PROVIDER_ID)
        val autofillId: AutofillId? = intent.getParcelableExtra(EXTRA_AUTOFILL_ID)

        if (providerId == null || autofillId == null) {
            setResult(RESULT_CANCELED)
            finish()
            return
        }

        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                val stored = KeyVault.get(applicationContext).get(providerId)
                if (stored == null) {
                    setResult(RESULT_CANCELED)
                    finish()
                    return
                }
                val value = AutofillValue.forText(stored.value)
                val dataset = Dataset.Builder()
                    .setValue(autofillId, value)
                    .build()

                val resultIntent = Intent().putExtra(
                    android.view.autofill.AutofillManager.EXTRA_AUTHENTICATION_RESULT,
                    dataset
                )
                setResult(RESULT_OK, resultIntent)
                finish()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                setResult(RESULT_CANCELED)
                finish()
            }

            override fun onAuthenticationFailed() {
                // A single failed attempt doesn't finish -- let the user retry
                // within BiometricPrompt's own retry/lockout handling.
            }
        })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.unlock_prompt_title))
            .setSubtitle(getString(R.string.unlock_prompt_subtitle))
            .setAllowedAuthenticators(
                androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        prompt.authenticate(promptInfo)
    }

    companion object {
        private const val EXTRA_PROVIDER_ID = "extra_provider_id"
        private const val EXTRA_AUTOFILL_ID = "extra_autofill_id"

        fun buildIntent(context: Context, providerId: String, autofillId: AutofillId): Intent =
            Intent(context, UnlockActivity::class.java)
                .putExtra(EXTRA_PROVIDER_ID, providerId)
                .putExtra(EXTRA_AUTOFILL_ID, autofillId)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_HISTORY)
    }
}
