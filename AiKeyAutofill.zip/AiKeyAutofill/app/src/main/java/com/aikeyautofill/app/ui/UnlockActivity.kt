package com.aikeyautofill.app.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.autofill.Dataset
import android.view.autofill.AutofillId
import android.view.autofill.AutofillValue
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.aikeyautofill.app.R
import com.aikeyautofill.app.crypto.KeyVault

/**
 * Invisible/transparent activity launched via the Dataset's authentication
 * IntentSender (see AiKeyAutofillService.buildLockedDataset). Its entire job:
 * prompt for biometrics, and only on success, decrypt the requested key from
 * the vault and hand it back to the Autofill framework as the fill result.
 *
 * If the user cancels or auth fails, we finish with RESULT_CANCELED and no
 * value is ever produced -- the field simply doesn't get filled. If the
 * device can't present ANY prompt (no lock screen configured, no biometric
 * hardware, etc.) we surface that with a Toast instead of silently finishing
 * to a black frame, which is what happened before this fix.
 */
class UnlockActivity : FragmentActivity() {

    private val allowedAuthenticators = BIOMETRIC_STRONG or DEVICE_CREDENTIAL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val providerId = intent.getStringExtra(EXTRA_PROVIDER_ID)
        val autofillId: AutofillId? = intent.getParcelableExtra(EXTRA_AUTOFILL_ID)

        if (providerId == null || autofillId == null) {
            finishCancelled()
            return
        }

        val biometricManager = BiometricManager.from(this)
        when (biometricManager.canAuthenticate(allowedAuthenticators)) {
            BiometricManager.BIOMETRIC_SUCCESS -> {
                // Proceed below.
            }
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                Toast.makeText(
                    this,
                    "Set a screen lock (PIN, pattern, or fingerprint) in Android Settings to use AI Key Autofill",
                    Toast.LENGTH_LONG
                ).show()
                finishCancelled()
                return
            }
            else -> {
                Toast.makeText(
                    this,
                    "This device can't verify identity right now, so the key wasn't filled",
                    Toast.LENGTH_LONG
                ).show()
                finishCancelled()
                return
            }
        }

        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                val stored = KeyVault.get(applicationContext).get(providerId)
                if (stored == null) {
                    Toast.makeText(
                        this@UnlockActivity,
                        "Couldn't find that saved key -- try adding it again",
                        Toast.LENGTH_LONG
                    ).show()
                    finishCancelled()
                    return
                }

                try {
                    val value = AutofillValue.forText(stored.value)
                    // Dataset.Builder() with no args only exists on API 28+.
                    // The RemoteViews-taking constructor has existed since
                    // API 26, so we use it here even though this particular
                    // RemoteViews is never actually shown (the picker UI
                    // already closed by this point) -- it's only present for
                    // cross-version compatibility.
                    val placeholderPresentation = android.widget.RemoteViews(
                        packageName,
                        R.layout.autofill_dataset_preview
                    )
                    val dataset = Dataset.Builder(placeholderPresentation)
                        .setValue(autofillId, value)
                        .build()

                    val resultIntent = Intent().putExtra(
                        android.view.autofill.AutofillManager.EXTRA_AUTHENTICATION_RESULT,
                        dataset
                    )
                    setResult(RESULT_OK, resultIntent)
                    Toast.makeText(this@UnlockActivity, "Key sent to the field", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(
                        this@UnlockActivity,
                        "Couldn't fill this field: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                    setResult(RESULT_CANCELED)
                }
                finish()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                // errString is user-facing text the framework already
                // localizes (e.g. "Too many attempts, try again later"); show
                // it rather than failing silently.
                if (errString.isNotBlank()) {
                    Toast.makeText(this@UnlockActivity, errString, Toast.LENGTH_SHORT).show()
                }
                finishCancelled()
            }

            override fun onAuthenticationFailed() {
                // A single failed attempt doesn't finish -- let the user retry
                // within BiometricPrompt's own retry/lockout handling.
            }
        })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.unlock_prompt_title))
            .setSubtitle(getString(R.string.unlock_prompt_subtitle))
            .setAllowedAuthenticators(allowedAuthenticators)
            .build()

        prompt.authenticate(promptInfo)
    }

    private fun finishCancelled() {
        setResult(RESULT_CANCELED)
        finish()
    }

    companion object {
        private const val EXTRA_PROVIDER_ID = "extra_provider_id"
        private const val EXTRA_AUTOFILL_ID = "extra_autofill_id"

        fun buildIntent(context: Context, providerId: String, autofillId: AutofillId): Intent =
            Intent(context, UnlockActivity::class.java)
                .putExtra(EXTRA_PROVIDER_ID, providerId)
                .putExtra(EXTRA_AUTOFILL_ID, autofillId)
    }
}
