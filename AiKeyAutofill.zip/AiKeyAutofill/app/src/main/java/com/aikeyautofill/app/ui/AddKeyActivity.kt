package com.aikeyautofill.app.ui

import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import com.aikeyautofill.app.R
import com.aikeyautofill.app.crypto.KeyVault
import com.aikeyautofill.app.model.Provider

/**
 * Two-step, fully manual, fully ToS-compliant "add a key" flow:
 *   1. User picks a provider and taps "Open console" -> we launch that
 *      provider's own key-creation page in a Custom Tab, using whatever
 *      session/login the user already has in their browser. We never touch
 *      login forms, CAPTCHAs, or account creation.
 *   2. User creates the key themselves on the provider's site, copies it,
 *      comes back here (or straight into whatever BYOK app they're using --
 *      onSaveRequest in AiKeyAutofillService catches that path too), and
 *      pastes it into the field below. We validate it against the
 *      provider's known key shape before saving, purely so we don't store
 *      obvious garbage.
 */
class AddKeyActivity : AppCompatActivity() {

    private lateinit var providerSpinner: Spinner
    private lateinit var keyInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_key)

        providerSpinner = findViewById(R.id.provider_spinner)
        keyInput = findViewById(R.id.key_input)

        providerSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            Provider.ALL.map { it.displayName }
        )

        findViewById<Button>(R.id.open_console_button).setOnClickListener {
            openConsoleForSelectedProvider()
        }

        findViewById<Button>(R.id.save_key_button).setOnClickListener {
            saveTypedKey()
        }
    }

    private fun selectedProvider(): Provider =
        Provider.ALL[providerSpinner.selectedItemPosition]

    private fun openConsoleForSelectedProvider() {
        val provider = selectedProvider()
        val customTabsIntent = CustomTabsIntent.Builder().build()
        customTabsIntent.launchUrl(this, Uri.parse(provider.consoleUrl))
    }

    private fun saveTypedKey() {
        val provider = selectedProvider()
        val typed = keyInput.text.toString().trim()

        if (typed.isEmpty()) {
            Toast.makeText(this, R.string.enter_a_key, Toast.LENGTH_SHORT).show()
            return
        }
        if (!provider.keyPattern.matches(typed)) {
            Toast.makeText(this, getString(R.string.key_shape_mismatch, provider.displayName), Toast.LENGTH_LONG).show()
            return
        }

        KeyVault.get(applicationContext).put(provider.id, "Manually added", typed)
        Toast.makeText(this, R.string.key_saved, Toast.LENGTH_SHORT).show()
        finish()
    }
}
