package com.aikeyautofill.app.detect

import android.app.assist.AssistStructure
import android.view.View
import android.view.autofill.AutofillId
import com.aikeyautofill.app.model.Provider

/**
 * There is no standard Android autofill hint for "API key" the way there is
 * for AUTOFILL_HINT_PASSWORD or AUTOFILL_HINT_USERNAME, so this is
 * necessarily heuristic. We combine several weak signals and require at
 * least a moderate combined score before we ever offer to fill something --
 * false positives are worse than false negatives here (silently not
 * offering to fill is fine; offering to fill the wrong thing is not).
 */
object FieldDetector {

    private val GENERIC_KEY_TERMS = listOf(
        "api key", "api_key", "apikey", "access key", "secret key",
        "x-api-key", "bearer token", "auth token"
    )

    data class Candidate(
        val autofillId: AutofillId,
        val provider: Provider?, // null = generic "some API key" field, unknown which provider
        val score: Int
    )

    /** Walks the whole window structure and returns scored candidate fields. */
    fun findCandidates(structure: AssistStructure): List<Candidate> {
        val results = mutableListOf<Candidate>()
        for (i in 0 until structure.windowNodeCount) {
            val root = structure.getWindowNodeAt(i).rootViewNode
            walk(root, results)
        }
        // Highest score per autofillId, deduped, sorted best-first.
        return results
            .groupBy { it.autofillId }
            .map { (_, cands) -> cands.maxByIterableScore() }
            .sortedByDescending { it.score }
    }

    private fun List<Candidate>.maxByIterableScore(): Candidate =
        this.maxByOrNull { it.score } ?: this.first()

    private fun walk(node: AssistStructure.ViewNode?, out: MutableList<Candidate>) {
        if (node == null) return

        val autofillId = node.autofillId
        val isTextField = node.className?.contains("EditText") == true ||
            node.autofillType == View.AUTOFILL_TYPE_TEXT

        if (isTextField && autofillId != null) {
            val haystack = buildString {
                append(node.hint ?: "")
                append(' ')
                append(node.idEntry ?: "")
                append(' ')
                append(node.text ?: "")
                append(' ')
                append(node.contentDescription ?: "")
                // A lot of BYOK apps render the field label as a *sibling*
                // TextView rather than a real <hint>. We approximate that by
                // also scanning the parent's other children's text, done at
                // the caller level in a second pass (see scoreWithSiblings).
            }.lowercase()

            var score = 0
            var matchedProvider: Provider? = null

            for (provider in Provider.ALL) {
                if (provider.fieldLabelHints.any { haystack.contains(it) }) {
                    score += 6
                    matchedProvider = provider
                    break
                }
            }
            if (GENERIC_KEY_TERMS.any { haystack.contains(it) }) {
                score += 4
            }
            // Password-style fields are the ones most BYOK apps use for keys
            // (to mask them on screen), so treat that as a supporting signal
            // -- but never a positive on its own, or we'd offer this on every
            // login screen for every app.
            if (node.inputType and INPUT_TYPE_TEXT_VARIATION_PASSWORD != 0) {
                if (score > 0) score += 2
            }

            if (score > 0) {
                out.add(Candidate(autofillId, matchedProvider, score))
            }
        }

        for (i in 0 until node.childCount) {
            walk(node.getChildAt(i), out)
        }
    }

    // android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD, restated to avoid
    // pulling in the full InputType class just for one constant in this file.
    private const val INPUT_TYPE_TEXT_VARIATION_PASSWORD = 0x00000080

    /**
     * Second pass: given a value the user just typed/pasted (onSaveRequest),
     * confirm or refine the provider guess purely from the value's shape.
     * This is the strong signal -- prefixes like "sk-ant-" or "AIza" are
     * close to unambiguous -- so it overrides a weaker field-label guess.
     */
    fun detectProviderFromValue(value: String): Provider? = Provider.detectByValue(value)
}
