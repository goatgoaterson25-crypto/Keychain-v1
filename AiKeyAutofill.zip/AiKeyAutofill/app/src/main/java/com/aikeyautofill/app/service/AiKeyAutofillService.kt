package com.aikeyautofill.app.service

import android.app.PendingIntent
import android.app.assist.AssistStructure
import android.content.Intent
import android.os.CancellationSignal
import android.service.autofill.*
import android.view.autofill.AutofillId
import android.view.autofill.AutofillValue
import android.widget.RemoteViews
import com.aikeyautofill.app.R
import com.aikeyautofill.app.crypto.KeyVault
import com.aikeyautofill.app.detect.FieldDetector
import com.aikeyautofill.app.model.Provider
import com.aikeyautofill.app.ui.UnlockActivity

class AiKeyAutofillService : AutofillService() {

    override fun onFillRequest(
        request: FillRequest,
        cancellationSignal: CancellationSignal,
        callback: FillCallback
    ) {
        val context = request.fillContexts.lastOrNull()
        val structure: AssistStructure = context?.structure
            ?: return callback.onSuccess(null)

        val candidates = FieldDetector.findCandidates(structure)
        if (candidates.isEmpty()) {
            callback.onSuccess(null)
            return
        }

        val vault = KeyVault.get(applicationContext)
        val stored = vault.all()
        if (stored.isEmpty()) {
            // Nothing saved yet -- don't offer empty datasets, just bail.
            callback.onSuccess(null)
            return
        }

        val responseBuilder = FillResponse.Builder()
        var offeredAny = false

        for (candidate in candidates) {
            // A candidate with a detected provider only gets that provider's
            // key offered. A generic "some key field" candidate (provider ==
            // null) gets every stored key offered, ranked by nothing in
            // particular -- the user picks from the preview list.
            val relevant = if (candidate.provider != null) {
                stored.filter { it.providerId == candidate.provider.id }
            } else {
                stored
            }

            for (storedKey in relevant) {
                val provider = Provider.byId(storedKey.providerId) ?: continue
                val dataset = buildLockedDataset(candidate.autofillId, provider, storedKey.value)
                responseBuilder.addDataset(dataset)
                offeredAny = true
            }
        }

        if (!offeredAny) {
            callback.onSuccess(null)
            return
        }

        callback.onSuccess(responseBuilder.build())
    }

    /**
     * Builds a Dataset whose value is NOT attached directly. Instead, the
     * dataset's authentication IntentSender points at UnlockActivity, which
     * runs a BiometricPrompt and only returns the real AutofillValue once
     * the user has authenticated -- so a key never sits decrypted in a
     * FillResponse waiting to be read by anything else on the device.
     */
    private fun buildLockedDataset(
        autofillId: AutofillId,
        provider: Provider,
        actualValue: String
    ): Dataset {
        val preview = RemoteViews(packageName, R.layout.autofill_dataset_preview).apply {
            setTextViewText(R.id.preview_text, provider.mask(actualValue))
        }

        val unlockIntent = UnlockActivity.buildIntent(this, provider.id, autofillId)
        val pendingIntent = PendingIntent.getActivity(
            this,
            provider.id.hashCode(),
            unlockIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )

        // value = null is deliberate: per the platform Dataset contract, a
        // dataset with setAuthentication() and a null value defers to the
        // IntentSender before anything is filled. UnlockActivity supplies
        // the real value only after a successful BiometricPrompt result.
        return Dataset.Builder(preview)
            .setValue(autofillId, null)
            .setAuthentication(pendingIntent.intentSender)
            .build()
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        val structure = request.fillContexts.lastOrNull()?.structure
        if (structure == null) {
            callback.onFailure(getString(R.string.save_failed_generic))
            return
        }

        val candidates = FieldDetector.findCandidates(structure)
        val vault = KeyVault.get(applicationContext)
        var savedAny = false

        for (candidate in candidates) {
            val value = extractTypedValue(structure, candidate.autofillId) ?: continue
            val provider = FieldDetector.detectProviderFromValue(value) ?: candidate.provider
            if (provider != null && provider.keyPattern.matches(value.trim())) {
                vault.put(provider.id, "Saved from ${request.packageName()}", value.trim())
                savedAny = true
            }
        }

        if (savedAny) callback.onSuccess() else callback.onFailure(getString(R.string.save_failed_no_match))
    }

    private fun SaveRequest.packageName(): String =
        fillContexts.lastOrNull()?.structure?.activityComponent?.packageName ?: "an app"

    private fun extractTypedValue(structure: AssistStructure, id: AutofillId): String? {
        for (i in 0 until structure.windowNodeCount) {
            val found = findNode(structure.getWindowNodeAt(i).rootViewNode, id)
            if (found != null) {
                val v: AutofillValue? = found.autofillValue
                return v?.takeIf { it.isText }?.textValue?.toString() ?: found.text?.toString()
            }
        }
        return null
    }

    private fun findNode(node: AssistStructure.ViewNode?, id: AutofillId): AssistStructure.ViewNode? {
        if (node == null) return null
        if (node.autofillId == id) return node
        for (i in 0 until node.childCount) {
            findNode(node.getChildAt(i), id)?.let { return it }
        }
        return null
    }
}
