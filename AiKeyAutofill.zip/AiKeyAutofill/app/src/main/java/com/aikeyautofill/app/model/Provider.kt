package com.aikeyautofill.app.model

/**
 * One entry per AI provider we recognize. Everything needed to (a) detect a
 * field that wants this provider's key, (b) validate/mask a pasted key, and
 * (c) send the user to the right "create a key" console page lives here, so
 * adding a new provider is a one-entry change, not a code change.
 */
data class Provider(
    val id: String,
    val displayName: String,
    // Regex matched against pasted/typed key values during save-capture.
    val keyPattern: Regex,
    // Terms matched (case-insensitively) against field hints/ids/sibling
    // labels to decide "this EditText wants a key from this provider".
    val fieldLabelHints: List<String>,
    // Where a user goes to create a new key for this provider. Opened in a
    // Custom Tab; we never touch this endpoint programmatically.
    val consoleUrl: String
) {
    /** Last 4 chars only -- used for the on-screen preview, never the full key. */
    fun mask(key: String): String {
        val tail = key.takeLast(4)
        return "$displayName · ••••$tail"
    }

    companion object {
        val OPENAI = Provider(
            id = "openai",
            displayName = "OpenAI",
            keyPattern = Regex("^sk-(proj-)?[A-Za-z0-9_-]{20,}$"),
            fieldLabelHints = listOf("openai", "gpt", "sk-"),
            consoleUrl = "https://platform.openai.com/api-keys"
        )

        val GEMINI = Provider(
            id = "gemini",
            displayName = "Google Gemini",
            keyPattern = Regex("^AIza[A-Za-z0-9_-]{20,}$"),
            fieldLabelHints = listOf("gemini", "google ai", "aiza", "generativelanguage"),
            consoleUrl = "https://aistudio.google.com/apikey"
        )

        val ANTHROPIC = Provider(
            id = "anthropic",
            displayName = "Anthropic Claude",
            keyPattern = Regex("^sk-ant-[A-Za-z0-9_-]{20,}$"),
            fieldLabelHints = listOf("anthropic", "claude", "sk-ant-"),
            consoleUrl = "https://console.anthropic.com/settings/keys"
        )

        val MISTRAL = Provider(
            id = "mistral",
            displayName = "Mistral",
            keyPattern = Regex("^[A-Za-z0-9]{32}$"),
            fieldLabelHints = listOf("mistral"),
            consoleUrl = "https://console.mistral.ai/api-keys"
        )

        val GROQ = Provider(
            id = "groq",
            displayName = "Groq",
            keyPattern = Regex("^gsk_[A-Za-z0-9]{20,}$"),
            fieldLabelHints = listOf("groq", "gsk_"),
            consoleUrl = "https://console.groq.com/keys"
        )

        val OPENROUTER = Provider(
            id = "openrouter",
            displayName = "OpenRouter",
            keyPattern = Regex("^sk-or-[A-Za-z0-9_-]{20,}$"),
            fieldLabelHints = listOf("openrouter", "sk-or-"),
            consoleUrl = "https://openrouter.ai/keys"
        )

        val ALL = listOf(OPENAI, GEMINI, ANTHROPIC, MISTRAL, GROQ, OPENROUTER)

        /** Best-guess provider for a pasted value, by pattern only. */
        fun detectByValue(value: String): Provider? =
            ALL.firstOrNull { it.keyPattern.matches(value.trim()) }

        fun byId(id: String): Provider? = ALL.firstOrNull { it.id == id }
    }
}
