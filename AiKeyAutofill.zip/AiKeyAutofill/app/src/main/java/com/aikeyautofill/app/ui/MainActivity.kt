package com.aikeyautofill.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.autofill.AutofillManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.aikeyautofill.app.R
import com.aikeyautofill.app.crypto.KeyVault
import com.aikeyautofill.app.model.Provider

class MainActivity : AppCompatActivity() {

    private lateinit var enableBanner: View
    private lateinit var keyListContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        enableBanner = findViewById(R.id.enable_banner)
        keyListContainer = findViewById(R.id.key_list_container)

        findViewById<Button>(R.id.enable_button).setOnClickListener {
            openAutofillSettings()
        }

        findViewById<Button>(R.id.add_key_button).setOnClickListener {
            startActivity(Intent(this, AddKeyActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshEnabledBanner()
        refreshKeyList()
    }

    private fun refreshEnabledBanner() {
        val afm = getSystemService(AutofillManager::class.java)
        val enabled = afm?.hasEnabledAutofillServices() == true
        enableBanner.visibility = if (enabled) View.GONE else View.VISIBLE
    }

    private fun openAutofillSettings() {
        // ACTION_REQUEST_SET_AUTOFILL_SERVICE lets us pre-select this app as
        // the target rather than dumping the user into the generic list.
        val intent = Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE)
        intent.data = Uri.parse("package:$packageName")
        try {
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun refreshKeyList() {
        keyListContainer.removeAllViews()
        val vault = KeyVault.get(applicationContext)
        val stored = vault.all()

        if (stored.isEmpty()) {
            val empty = TextView(this).apply {
                text = getString(R.string.no_keys_yet)
                setPadding(0, 32, 0, 32)
            }
            keyListContainer.addView(empty)
            return
        }

        val inflater = LayoutInflater.from(this)
        for (entry in stored) {
            val provider = Provider.byId(entry.providerId) ?: continue
            val row = inflater.inflate(R.layout.row_stored_key, keyListContainer, false)
            row.findViewById<TextView>(R.id.row_title).text = provider.displayName
            row.findViewById<TextView>(R.id.row_subtitle).text = provider.mask(entry.value)
            row.findViewById<Button>(R.id.row_delete).setOnClickListener {
                vault.delete(entry.providerId)
                refreshKeyList()
            }
            keyListContainer.addView(row)
        }
    }
}
