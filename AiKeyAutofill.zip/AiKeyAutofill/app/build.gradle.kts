plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aikeyautofill.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aikeyautofill.app"
        minSdk = 26 // AutofillService requires API 26+
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Biometric gating for decrypting keys on each fill
    implementation("androidx.biometric:biometric:1.1.0")

    // Custom Tabs for deep-linking into provider consoles (login stays in
    // the user's own browser session; we never touch it programmatically)
    implementation("androidx.browser:browser:1.8.0")

    // Encrypted at-rest storage backed by Android Keystore
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // Lifecycle / coroutines for async fill/save requests
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
}
